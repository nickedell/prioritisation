export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}// JavaScript Document